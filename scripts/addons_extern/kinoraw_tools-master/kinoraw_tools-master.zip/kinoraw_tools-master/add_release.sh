sh dev-scripts/pandoc.sh
sh dev-scripts/zipgen.sh $1