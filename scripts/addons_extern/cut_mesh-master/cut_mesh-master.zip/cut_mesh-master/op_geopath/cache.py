'''
Created on Oct 8, 2015

@author: Patrick
'''
geopath_undo_cache = []