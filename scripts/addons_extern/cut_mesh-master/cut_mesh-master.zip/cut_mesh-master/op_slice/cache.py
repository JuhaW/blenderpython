'''
Created on Oct 8, 2015

@author: Patrick
'''
slice_undo_cache = []