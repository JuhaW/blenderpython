'''
Created on Oct 8, 2015
@author: Patrick Moore

'''

__all__ = ["slice_modal"]