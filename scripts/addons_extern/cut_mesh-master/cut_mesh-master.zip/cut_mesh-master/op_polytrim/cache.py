'''
Created on Oct 8, 2015

@author: Patrick
'''
polytrim_undo_cache = []