Wire
====================================================================================
Blender - rendering in cycles with wireframe.

====================================================================================
Installation

User Preferences - Addons - Install from file
    
    __init__.py

====================================================================================
Usage

Ctrl + Shift + F12 in 3D view window

====================================================================================
Result

<img src="http://i.imgur.com/h1GQgLH.jpg" title="source: imgur.com">
