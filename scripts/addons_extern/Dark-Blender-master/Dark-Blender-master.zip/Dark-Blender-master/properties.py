import bpy
from bpy.props import IntProperty, BoolProperty, FloatProperty, EnumProperty, PointerProperty, StringProperty, CollectionProperty
from bpy.types import PropertyGroup

#class ObjectItem(PropertyGroup):
#    name = StringProperty(
#        name="",
#        description="The name of the group."
#    )

#classes = (ObjectItem)

#for cls in classes:
    #bpy.utils.register_class(cls)

#bpy.utils.register_class(ObjectItem)

#bpy.types.Scene.GXScn = PointerProperty(type=GX_Scene_Preferences)
