# BlenderAndMBDyn
Combines Blender's graphical interface and rendering capabilities with MBDyn's multi-body dynamics, aerodynamics, and aeroelastics simulation and analysis, for rapid modeling and realistic rendering of physics based multi-body simulations.

For a very brief video introduction, watch here: https://www.youtube.com/watch?v=Fb4ExUd_mGI
