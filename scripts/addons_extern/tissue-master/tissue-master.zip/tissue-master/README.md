# Tissue
Tissue - Blender's add-on for computational design by Co-de-iT
http://www.co-de-it.com/wordpress/code/blender-tissue

Latest version (master): https://github.com/alessandro-zomparelli/tissue/archive/master.zip

Releases: https://github.com/alessandro-zomparelli/tissue/releases

Installation:

1. Start Blender. Open User Preferences, the addons tab 
2. Click "install from file" and point Blender at the downloaded zip
3. Activate Tissue add-on from user preferences
3. Save user preferences if you want to have it on at startup.
