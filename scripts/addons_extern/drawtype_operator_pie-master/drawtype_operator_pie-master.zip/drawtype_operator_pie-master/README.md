# drawtype_operator_pie
For fast changing of object draw type while working with image planes
