# meltdown
Support addon for Blender to streamline baking with Cycles
Just some fixes:
- no longer crash when obj has not material when baking - instead display obj name
- support for baking obj, made with GroupPro addon.
