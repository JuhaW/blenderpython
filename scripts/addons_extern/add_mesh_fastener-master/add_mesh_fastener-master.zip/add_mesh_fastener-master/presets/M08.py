# Thread
props.bf_Pitch = 1.25  # Coarse
props.bf_Crest_Percent = 10
props.bf_Root_Percent = 10
props.bf_Major_Dia = 8.0
props.bf_Minor_Dia = props.bf_Major_Dia - (1.082532 * props.bf_Pitch)
# Head
props.bf_Hex_Head_Flat_Distance = 13.0
props.bf_Hex_Head_Height = 5.3
props.bf_Cap_Head_Dia = 13.5
props.bf_Cap_Head_Height = 8.0
props.bf_CounterSink_Head_Dia = 17.3
props.bf_Pan_Head_Dia = 16.0
props.bf_Dome_Head_Dia = 16.0
# Bit
props.bf_Allen_Bit_Flat_Distance = 6.0
props.bf_Allen_Bit_Depth = 4.0
props.bf_Philips_Bit_Dia = props.bf_Pan_Head_Dia * (1.82 / 5.6)
# Nut
props.bf_Hex_Nut_Height = 6.5
props.bf_Hex_Nut_Flat_Distance = 13.0
# Shank
props.bf_Shank_Dia = 8.0
props.bf_Length = 16
#props.bf_Thread_Length =
#props.bf_Shank_Length =
