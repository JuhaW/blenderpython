# Blender Addon 'QuadView Move'

![Image](image.jpg)

QuadView中央の境界をドラックする事でサイズを変更する。  
ドラッグ中にESCキーで初期化。  
レンダリング中は動作しない。  

※ 公式のblender-2.76(a,b)以外での動作は未確認。それ以外ではデータの破損や強制終了等を引き起こす可能性があるので使用には十分注意する事。