# blender-EditMeshDrawNearest

マウスクリックで次に選択するであろう要素を強調表示する。

![](images/img.jpg)  

## 設定項目

* Mask: 頂点が隠れないようにする。  
![](images/u_mask_none.jpg)  
'None'  
![](images/mask_none.jpg)  
'Depth'  
![](images/mask_depth.jpg)  

* DerivedMesh: 描画に編集ケージを用いる。  
![](images/u_derived.jpg)  
![](images/use_derived.jpg)  
