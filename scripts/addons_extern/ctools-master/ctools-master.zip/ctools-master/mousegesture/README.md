# Blender Addon 'Mouse Gesture'

初期設定ではActionMouseドラッグで視点切り替えが行える。  
ジェスチャーの詳細はUserPreferenceを参照。  

![Image](img_01.jpg)

![Image](img_02.jpg)

![Image](img_03.jpg)
