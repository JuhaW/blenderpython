# Blender Addon 'Region Ruler'

![Image](image.jpg)
