# Blender Addon 'Lock 3D Cursor'

![Image](img.jpg)


commit a791153ca5e6f87d50396e188a3664b579884161  
3D Cursor: Add option to lock it in place to prevent accidental modification  

これを再現したものになります  

各SpaceView3DのフラグはScreenのIDPropertyに保存されます
