# Blender Addon 'Update Tag'

1. マテリアルのドライバーの値が変更された時に3DViewを更新  
利用するにはMaterialプロパティのDriverUpdateTagパネルのEnableにチェックを入れる  
2. Sculptモードでブラシ描画の際にRendered表示の3DViewを更新
