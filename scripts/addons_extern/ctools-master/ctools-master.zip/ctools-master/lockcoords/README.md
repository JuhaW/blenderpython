# Blender Addon 'Lock Coordinates'

![Image](img.jpg)


Mesh編集中に頂点座標を固定・選択不可にするアドオン。  
それなりの負荷がかかる。  
レンダリング中は動作しない。  
頂点の並び順を変えるのでShapeKeyで不具合が出るかも。  
頂点レイヤーを使うのでファイルサイズが増加する。int型なので最大で頂点数x4バイト？